java -classpath clojure.jar clojure.main prefixer.clj $1 $2
